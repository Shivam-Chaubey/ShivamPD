from setuptools import setup

setup(name='shivam_PD',
      version='1.0',
      description='This python package is created to help user to perform complex mathematical operations in Probability Distribution.',
      packages=['shivam_PD'],
      author = 'Shivam Chaubey',
      author_email = 'shivamchaubey83@gmail.com',
      zip_safe=False)
